OfficeFiles sample archive.
